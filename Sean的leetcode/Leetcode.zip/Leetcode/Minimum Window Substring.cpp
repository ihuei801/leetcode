//https://leetcode.com/discuss/20053/three-concise-implemetation-according-leetcode-oj-discuss

//use two pointers (left, right) to find the match region.
//1. advance right index to collect enough char.
//2. advance left index to shrink the (left, right) region.
//3. advance left index and right index to find the next possible solution.
//4. repeat step1-step3
class Solution {
public:
    string minWindow(string s, string t) {
        int left = 0, right = 0;
        unordered_map<char, int>t_map;
        int min_len = INT_MAX;
        int start_idx;
        int count = 0;
        for (auto c : t)
            t_map[c]++;

        while (right < s.size())
        {
            t_map[s[right]]--;

            if (t_map[s[right]] >= 0)
                count++;

            while (count == t.size())
            {
                if (right - left + 1 < min_len)
                {
                    min_len = right - left + 1;
                    start_idx = left;
                }
                t_map[s[left]]++;
                if (t_map[s[left]] > 0)
                    count--;
                left++;
            }
            right++;
        }

        return min_len == INT_MAX ? "" : s.substr(start_idx, min_len);
    }
};