//http://www.cnblogs.com/jcliBlogger/p/4708243.html
class Solution {
public:
    bool isStrobogrammatic(string num) {
        unordered_map<char, char> n_map;
        n_map['0'] = '0';
        n_map['1'] = '1';
        n_map['6'] = '9';
        n_map['8'] = '8';
        n_map['9'] = '6';
        int n = num.size();
        int left = 0;
        int right = n - 1;
        while (left <= right)
        {
            if (!n_map.count(num[left]) || n_map[num[left++]] != num[right--])
                return false;
        }
        return true;
    }
};