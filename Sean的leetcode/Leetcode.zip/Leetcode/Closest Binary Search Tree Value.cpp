#if //iterative solution
//https://leetcode.com/discuss/54438/4-7-lines-recursive-iterative-ruby-c-java-python
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
//Time: O(logN)
class Solution {
public:
    int closestValue(TreeNode* root, double target) {

        if (!root) return INT_MIN;

        int closet_val = root->val;
        TreeNode *curr = root;
        while (curr)
        {
            if (curr->val == target)
                return curr->val;
            if (abs(curr->val - target) < abs(closet_val - target))
                closet_val = curr->val;
            curr = curr->val > target ? curr->left : curr->right;
        }
        return closet_val;
    }
};
#elif 1 //recursive solution
//https://leetcode.com/discuss/54438/4-7-lines-recursive-iterative-ruby-c-java-python
class Solution {
public:
    int closestValue(TreeNode* root, double target) {
        if (!root) return INT_MAX;

        TreeNode *child = root->val < target ? root->right : root->left;

        if (!child) return root->val;

        int c_val = closestValue(child, target);
        return abs(root->val - target) < abs(c_val - target) ? root->val : c_val;
    }
};
#endif;