//https://leetcode.com/discuss/52442/o-n-2-c-solution
class Solution {
public:
    int threeSumSmaller(vector<int>& nums, int target) {

        sort(nums.begin(),nums.end());

        int count = 0;
        for (int i = 0; i < n - 2; i++)
            for (int j = i+1, k = n-1; j < k;)
            {
                if (nums[i] + nums[j] + nums[k] >= target)
                    k--;
                else
                {
                    count += k - j;
                    j++;
                }
            }
        return count;
    }
};