#if 1 //Time: O(N), Space: O(1)
//https://leetcode.com/discuss/31292/clean-11-lines-ac-answer-o-1-space-o-n-time
class Solution {
public:
    int lengthOfLongestSubstringTwoDistinct(string s) {
        int max_len = 0;
        int last_diff = -1;
        int start = 0;
        for (int i = 1; i < s.size(); i++)
        {
            if (s[i] == s[i-1])
                continue;
            if (last_diff != -1 && s[i] != s[last_diff])
            {
                max_len = max(max_len, i - start);
                start = last_diff + 1;
            }
            last_diff = i - 1;
        }
        return max_len  > s.size() - start ? max_len : s.size() - start;
    }
};
#elif 1// Time: O(N), Space: O(N)
class Solution {
public:
    int lengthOfLongestSubstringTwoDistinct(string s) {
        unordered_map<char, int> c_map;
        int max_len = 0;
        int left = 0;
        int right;
        int count = 0;
        for (right = 0; right < s.size(); right++)
        {
            if (!c_map.count(s[right]) || !c_map[s[right]])
                count++;

            c_map[s[right]]++;
            while (count > 2)
            {
                c_map[s[left]]--;
                if (c_map[s[left]] == 0)
                    count--;
                left++;
            }
            max_len = max(max_len, right - left + 1);
        }
        return max_len;
    }
};
#endif