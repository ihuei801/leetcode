//https://leetcode.com/discuss/63659/two-java-solution
//https://leetcode.com/discuss/63684/simple-java-solution-with-explanation
class Solution {
public:
    bool canWinNim(int n) {
        return n % 4 != 0;
    }
};