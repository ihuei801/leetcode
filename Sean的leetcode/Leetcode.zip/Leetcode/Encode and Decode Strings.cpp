class Codec {
public:

    // Encodes a list of strings to a single string.
    string encode(vector<string>& strs) {
        string res;
        for (auto s : strs)
            res += to_string(s.size())+"#"+s;
        return res;
    }

    // Decodes a single string to a list of strings.
    vector<string> decode(string s) {
        vector<string> res;
        int i = 0;
        while (i < s.size())
        {
            string sub = s.substr(i);
            int p = sub.find("#");
            int len = stoi(sub.substr(0, p));
            res.push_back(sub.substr(p+1, len));
            i += p + len + 1;
        }
        return res;
    }
};

// Your Codec object will be instantiated and called as such:
// Codec codec;
// codec.decode(codec.encode(strs));