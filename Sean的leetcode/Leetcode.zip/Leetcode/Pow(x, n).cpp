class Solution {
public:
    double myPow(double x, int n) {
        if (n == 0) return 1;

        int exp = n;
        if (exp < 0) exp = -exp;

        double res = myPow(x, exp >> 1);
        res *= res;

        if (exp & 1)
            res *= x;

        return (n < 0) ? 1/res : res;
    }
};