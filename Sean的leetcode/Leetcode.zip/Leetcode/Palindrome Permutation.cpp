class Solution {
public:
    bool canPermutePalindrome(string s) {
        unordered_map<char, int> c_map;
        int odd = 0;
        for (auto c : s)
        {
            c_map[c]++;
            if (c_map[c] & 1)
                odd++;
            else
                odd--;
        }
        return odd <= 1;
    }
};