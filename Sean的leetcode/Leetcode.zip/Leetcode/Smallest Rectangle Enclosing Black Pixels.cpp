//DFS, Time: O(mn)
class Solution {
public:
    void dfs(vector<vector<char>>& image, int row, int col, int &min_row, int &max_row, int &min_col, int &max_col)
    {
        int dir[] = {0, 1, 0, -1, 0};
        int M_row = image.size();

        if (!M_row) return;

        int M_col = image[0].size();

        if (row < 0 || col < 0 || row >= M_row || col >= M_col)
            return;

        if (image[row][col] == '1')
        {
            if (row < min_row) min_row = row;
            if (row > max_row) max_row = row;
            if (col < min_col) min_col = col;
            if (col > max_col) max_col = col;
            image[row][col] = 0;
            for (int i = 0; i < 4; i++)
                dfs(image, row+dir[i], col+dir[i+1], min_row, max_row, min_col, max_col);
        }
    }

    int minArea(vector<vector<char>>& image, int x, int y) {
        int min_row = INT_MAX, min_col = INT_MAX;
        int max_row = INT_MIN, max_col = INT_MIN;

        int M_row = image.size();

        if (!M_row) return 0;

        dfs(image, x, y, min_row, max_row, min_col, max_col);

        return (max_row - min_row + 1) * (max_col - min_col + 1);
    }
};