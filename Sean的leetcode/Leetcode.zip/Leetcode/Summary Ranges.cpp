class Solution {
public:
    vector<string> summaryRanges(vector<int>& nums) {
        vector<string>res;
        int i;
        if (nums.size() == 0) return res;

        int start = nums[0];

        if (nums.size() == 1)
        {
            res.push_back(to_string(nums[0]));
            return res;
        }

        for (i = 1; i < nums.size(); i++)
        {
            if (nums[i] != nums[i-1] + 1)
            {
                if (start == nums[i-1])
                    res.push_back(to_string(start));
                else
                    res.push_back(to_string(start)+"->"+to_string(nums[i-1]));

                start = nums[i];
            }
        }
        if (start == nums[i-1])
            res.push_back(to_string(start));
        else
            res.push_back(to_string(start)+"->"+to_string(nums[i-1]));
    }
};