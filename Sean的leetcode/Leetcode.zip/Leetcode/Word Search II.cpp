//https://leetcode.com/discuss/36660/my-ac-solution-using-trie
//1. construct all words into a trie.
//2. use the trie to compare all possible words in DFS.
class Solution {
    struct TrieNode {
        map<char, TrieNode*>table;
        int is_word;
        TrieNode(): is_word(0) {}
    };

    void insert(TrieNode *root, string word)
    {
        TrieNode *curr = root;
        int size = word.size();
        for (int i = 0; i < size; i++)
        {
            if (curr->table.count(word[i]) == 0)
                curr->table[word[i]] = new TrieNode();

            curr = curr->table[word[i]];
        }
        curr->is_word = 1;
    }

    void dfs(TrieNode *root, vector<vector<char>>& board, int row, int col, string &one_sol, vector<string> &res)
    {
        if (!root
            || row < 0
            || col < 0
            || row > board.size()-1
            || col > board[0].size()-1)
            return;

        if (board[row][col] == NULL || !root->table.count(board[row][col]))
            return;

        char t = board[row][col];
        TrieNode *next = root->table[t];

        one_sol.push_back(t);
        if (next->is_word)
        {
            res.push_back(one_sol);
            //set to 0 to prevent duplicate one_sol.
            next->is_word = 0;
        }

        board[row][col] = NULL;

        dfs(next, board, row+1, col, one_sol, res);
        dfs(next, board, row, col+1, one_sol, res);
        dfs(next, board, row-1, col, one_sol, res);
        dfs(next, board, row, col-1, one_sol, res);

        one_sol.pop_back();
        board[row][col] = t;
    }

public:
    vector<string> findWords(vector<vector<char>>& board, vector<string>& words) {
        TrieNode *root = new TrieNode();
        int rows = board.size();
        int cols = board[0].size();
        vector<string>res;
        string one_sol;
        int word_count = words.size();

        //build trie tree
        for (int i = 0; i < word_count; i++)
            insert(root, words[i]);

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols && res.size() < word_count; j++)
            {
                dfs(root, board, i, j, one_sol, res);
            }
        return res;
    }
};