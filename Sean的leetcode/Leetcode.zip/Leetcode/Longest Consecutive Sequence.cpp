class Solution {
public:
    int longestConsecutive(vector<int>& nums) {
        unordered_set<int> s(nums.begin(), nums.end());
        int max_len = 0;
        for (auto i : nums)
        {
            if (!s.count(i)) continue;

            s.erase(i);
            int j = i-1, k = i+1;
            while (s.count(j)) s.erase(j--);
            while (s.count(k)) s.erase(k++);
            max_len = max(max_len, k-j-1);
        }
        return max_len;
    }
};