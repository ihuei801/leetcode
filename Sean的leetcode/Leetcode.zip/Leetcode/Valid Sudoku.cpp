//https://oj.leetcode.com/discuss/14929/very-simple-c-solution
class Solution {
public:
    bool isValidSudoku(vector<vector<char> > &board) {
        vector<vector<int> > check(3, vector<int>(9, 0));

        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                int row, col;
                if (board[i][j] != '.' && ++check[0][board[i][j]-'1'] > 1) return false;
                if (board[j][i] != '.' && ++check[1][board[j][i]-'1'] > 1) return false;

                row = j/3 + 3*(i/3);
                col = j%3 + 3*(i%3);
                if (board[row][col] != '.' && ++check[2][board[row][col]-'1'] > 1) return false;
            }

            for (int k = 0; k < 3; k++)
                check[k].assign(9, 0);
        }
        return true;
    }
};