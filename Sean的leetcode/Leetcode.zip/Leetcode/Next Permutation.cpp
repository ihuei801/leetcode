//https://leetcode.com/discuss/47076/1-4-11-lines-c
class Solution {
public:
    void nextPermutation(vector<int>& nums) {
        int left = nums.size() - 1;
        int right = left;
        int i, j;
        while (left > 0 && nums[left-1] >= nums[left])
            left--;

        i = left;
        while (left < right)
            swap(nums[left++], nums[right--]);

        if (i > 0)
        {
            j = i;
            i--;
            while (nums[j] <= nums[i])
                j++;
            swap(nums[i], nums[j]);
        }
    }
};