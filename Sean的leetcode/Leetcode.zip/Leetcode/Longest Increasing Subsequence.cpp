//http://www.geeksforgeeks.org/longest-monotonically-increasing-subsequence-size-n-log-n/
//Time: O(NlogN)
class Solution {
public:
    int lengthOfLIS(vector<int>& nums) {
        int n = nums.size();

        vector<int> lis;

        for (auto a : nums)
        {
            if (lis.empty())
                lis.push_back(a);
            else if (a < lis[0])
                lis[0] = a;
            else if (a > lis.back())
                lis.push_back(a);
            else
            {
                int left = 0;
                int right = lis.size()-1;
                while (left <= right)
                {
                    int mid = left + ((right - left) >> 1);
                    //note: this should be ">=" to overwrite lis[mid] equal to a.
                    if (lis[mid] >= a)
                        right = mid - 1;
                    else
                        left = mid + 1;
                }
                lis[left] = a;
            }
        }
        return lis.size();
    }
};