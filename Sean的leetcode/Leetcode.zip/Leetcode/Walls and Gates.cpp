//https://leetcode.com/discuss/60418/c-bfs-clean-solution-with-simple-explanations
class Solution {
public:
    void wallsAndGates(vector<vector<int>>& rooms) {
        int row = rooms.size();
        if (!row) return;

        int col = rooms[0].size();

        queue<pair<int,int>> q;

        for (int i = 0; i < row; i++)
            for (int j = 0; j < col; j++)
            {
                if (!rooms[i][j])
                    q.push(make_pair(i, j));
            }

        while (!q.empty())
        {
            int r_val = q.front().first;
            int c_val = q.front().second;
            q.pop();
            int dir[] = {0, 1, 0, -1, 0};
            for (int i = 0; i < 4; i++)
            {
                int r = r_val + dir[i];
                int c = c_val + dir[i+1];
                if (r < 0 || c < 0 || r >= row || c >= col
                    || rooms[r_val][c_val]+1 >= rooms[r][c])
                    continue;

                rooms[r][c] = rooms[r_val][c_val]+1;
                q.push(make_pair(r, c));
            }
        }
    }
};