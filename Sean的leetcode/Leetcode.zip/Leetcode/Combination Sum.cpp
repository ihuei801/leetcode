class Solution {
public:

    void do_combine(vector<int> candidates,
                    vector<vector<int> > &res, 
                    vector<int> &solution, 
                    int target, 
                    int *curr_sum,
                    int start)
    {
        
        if (*curr_sum > target)
            return;
        else if (*curr_sum == target)
        {
            res.push_back(solution);
            return;
        }
        
        for (int i = start; i < candidates.size(); i++)
        {
            solution.push_back(candidates[i]);
            *curr_sum += candidates[i];
            do_combine(candidates, res, solution, target, curr_sum, i);
            *curr_sum -= candidates[i];
            solution.pop_back();
        }
    }
    
    vector<vector<int> > combinationSum(vector<int> &candidates, int target) {
        
        vector<vector<int> >res;
        vector<int>solution;
        int curr_sum = 0;
        
        sort(candidates.begin(), candidates.end());
        do_combine(candidates, res, solution, target, &curr_sum, 0);
        return res;                
    }
};