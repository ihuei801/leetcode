class Solution {
public:
    int mySqrt(int x) {
        long long left = 0, right = (x >> 1) + 1;

        if (x < 0) return -1;

        while (left <= right)
        {
            //use long long to prevent INT overflow.
            long long mid = (left + right) >> 1;
            long long m_square = mid * mid;

            if (x == m_square)
                return mid;
            else if (x > m_square)
                left = mid + 1;
            else
                right = mid - 1;
        }
        //break condition becomes [right, left], which means right*right < x. so, return right.
        return right;
    }
};