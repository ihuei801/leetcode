class Solution {
public:
    void doComb(string s, int start, string &one_sol, vector<string> &res)
    {
        vector<string> dict = {" ", "", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz"};

        /*
           note: need to consider if '1' is the last character.
           We need to push one_sol to res. Because '1' is mapping to empty string,
           the following "for-loop" won't be executed.
           However, leetcode test data don't cover this test case.
        */
        if (start == s.size() || (start == s.size() - 1 && s[start] == '1'))
        {
            res.push_back(one_sol);
            return;
        }

        string m_str = dict[s[start]-'0'];
        for (int j = 0; j < m_str.size(); j++)
        {
            one_sol += m_str[j];
            doComb(s, start+1, one_sol, res);
            one_sol.pop_back();
        }
    }

    vector<string> letterCombinations(string digits) {
        string one_sol;
        vector<string> res;
        if (digits == "")
            return res;
        doComb(digits, 0, one_sol, res);
        return res;
    }
};